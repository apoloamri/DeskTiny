﻿using DTCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace $safeprojectname$
{
    public class Startup : DTStartup
    {
        public Startup(IConfiguration configuration) { }
    }
}

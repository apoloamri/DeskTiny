﻿using Tenderfoot.Mvc;
using Microsoft.Extensions.Configuration;

namespace $safeprojectname$
{
    public class Startup : TfStartup
    {
        public Startup(IConfiguration configuration) { }
    }
}
